'use strict';
// Git helpers. Each takes an optional { host } (core/host.js) so a project on an SSH host is read there.
const fs = require('fs');
const path = require('path');
const { localHost } = require('./host');
const { parseNumstat } = require('./change-stats');
const { readPathCommand } = require('./path-command');
const { pathPrefixFromText } = require('./path-prefix');

const run = (cwd, args, max = 200000, host = localHost) => host.exec('git', args, { cwd, timeout: 8000, maxBuffer: max * 4 })
  .then((r) => (r.code === 0 ? String(r.stdout) : null));

async function gitInfo(cwd, { host = localHost } = {}) {
  const top = await run(cwd, ['rev-parse', '--show-toplevel'], undefined, host);
  if (!top) return null;
  const [branch, status, stat, numstat] = await Promise.all([
    run(cwd, ['rev-parse', '--abbrev-ref', 'HEAD'], undefined, host),
    run(cwd, ['status', '--porcelain=v1', '-z', '--untracked-files=all'], undefined, host),
    run(cwd, ['diff', 'HEAD', '--stat', '--stat-width=100'], undefined, host),
    run(cwd, ['diff', 'HEAD', '--numstat', '-z', '--no-renames'], undefined, host),
  ]);
  const counts = parseNumstat(numstat);
  const changed = []; const records = (status || '').split('\0');
  for (let i = 0; i < records.length; i++) {
    const record = records[i]; if (!record) continue;
    const code = record.slice(0, 2).trim(); const entry = { code, path: record.slice(3) };
    if (/[RC]/.test(code)) entry.from = records[++i];
    Object.assign(entry, counts.get(entry.path));
    changed.push(entry);
  }
  return { root: top.trim(), branch: (branch || '').trim(), changed, stat: (stat || '').trim() };
}

// Fingerprint dirty files so we can tell which ones a turn touched, however it edited them.
function fingerprint(root, changed) {
  const m = new Map();
  for (const c of changed || []) { try { const st = fs.statSync(path.join(root, c.path)); m.set(c.path, `${st.mtimeMs}:${st.size}`); } catch { m.set(c.path, 'deleted'); } }
  return m;
}
// The same, on any host (one round trip for a remote one).
async function fingerprintsOn(host, root, changed) {
  const abs = (changed || []).map((c) => host.path.join(root, c.path));
  const prints = await host.fingerprints(abs);
  return new Map((changed || []).map((c, i) => [c.path, prints.get(abs[i])]));
}
// prev: fingerprint Map taken before the turn; after: gitInfo() after the turn; now: after's
// fingerprints when they were taken elsewhere (fingerprintsOn).
function touched(prev, after, now) {
  if (!after) return [];
  prev = prev || new Map();
  now = now || fingerprint(after.root, after.changed);
  const out = [];
  for (const c of after.changed) if (prev.get(c.path) !== now.get(c.path)) out.push(c);
  for (const [p] of prev) if (!now.has(p)) out.push({ code: 'reverted', path: p });
  return out;
}

async function fileDiff(cwd, rel, { host = localHost } = {}) {
  if (typeof rel !== 'string' || !rel || host.path.isAbsolute(rel) || rel.includes('\0')) throw new Error('Choose a relative project file.');
  const relative = host.path.relative(cwd, host.path.resolve(cwd, rel));
  if (relative === '..' || relative.startsWith(`..${host.path.sep}`)) throw new Error('Path outside project');
  if (!host.remote) await require('./files').projectPath(cwd, rel, true);
  const tracked = await run(cwd, ['ls-files', '--error-unmatch', '--', rel], undefined, host);
  if (tracked) { const diff = await run(cwd, ['diff', 'HEAD', '--', rel], 5_000_000, host); if (diff !== null) return diff; }
  try {
    const data = await host.readFile(host.path.join(cwd, rel), { maxBytes: 1024 * 1024 + 1 });
    if (data.length > 1024 * 1024) return 'File is larger than 1 MB. Open it in your editor for the complete comparison.';
    if (data.includes(0)) return 'Binary file. Open it in a suitable viewer.';
    const t = data.toString('utf8'); return `new file ${rel}\n` + (t ? t.replace(/\n$/, '').split('\n').map((l) => `+${l}`).join('\n') : '');
  } catch { return ''; }
}

const headContent = (cwd, rel, { host = localHost } = {}) => run(cwd, ['show', `HEAD:${rel.replace(/\\/g, '/')}`], 5_000_000, host);

const SKIP = ['node_modules', '.git', 'dist', 'build', '.venv', '__pycache__', '.next'];

// Files for @-mentions: tracked and untracked, honoring .gitignore. Falls back to a shallow walk.
async function listFiles(cwd, limit = 20000, { host = localHost } = {}) {
  if (!Number.isSafeInteger(limit) || limit < 0) throw new RangeError('Invalid file limit');
  if (!limit) return [];
  const args = ['ls-files', '--cached', '--others', '--exclude-standard', '-z'];
  if (typeof host.spawn === 'function') {
    const result = await readPathCommand(host, 'git', args, { cwd, limit });
    if (result.ok) return result.files;
  } else {
    const out = await run(cwd, args, 50_000_000, host);
    if (out != null) return pathPrefixFromText(out, limit);
  }
  if (host.remote) {
    const prune = SKIP.flatMap((n, i) => [...(i ? ['-o'] : []), '-name', n]);
    const args = ['.', '-maxdepth', '7', '(', ...prune, '-o', '-name', '.*', '!', '-name', '.', ')', '-prune', '-o', '-type', 'f'];
    if (typeof host.spawn === 'function') {
      const result = await readPathCommand(host, 'find', [...args, '-print0'], { cwd, limit, timeout: 15000, maxBytes: 64 * 1024 * 1024, stripDot: true });
      return result.files;
    }
    const r = await host.exec('find', [...args, '-print'], { cwd, timeout: 15000 });
    return pathPrefixFromText(String(r.stdout), limit, { separator: '\n', stripDot: true });
  }
  const files = []; const skip = new Set(SKIP);
  const walk = (dir, depth) => {
    if (depth > 6 || files.length >= limit) return;
    let ents = []; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) { if (files.length >= limit) break; if (skip.has(e.name) || e.name.startsWith('.')) continue; const p = path.join(dir, e.name); if (e.isDirectory()) walk(p, depth + 1); else files.push(path.relative(cwd, p)); }
  };
  walk(cwd, 0); return files;
}

async function commitAll(cwd, message, { host = localHost } = {}) {
  const sh = async (args) => { const r = await host.exec('git', args, { cwd, timeout: 30000 }); if (r.code !== 0) throw new Error(String(r.stderr || r.stdout).trim()); return String(r.stdout); };
  await sh(['add', '-A']);
  const out = await sh(['commit', '-m', message]);
  return out.split('\n')[0];
}

module.exports = { gitInfo, headContent, fileDiff, touched, fingerprint, fingerprintsOn, listFiles, commitAll };
