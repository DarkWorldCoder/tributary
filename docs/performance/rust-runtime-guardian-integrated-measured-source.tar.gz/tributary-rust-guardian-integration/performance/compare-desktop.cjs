'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const repo = "/tmp/tributary-runtime-publication-n9zndl_k", root = '/tmp/tributary-rust-guardian-integration/performance';
const output = path.join(root, 'desktop-comparison.json'), resume = process.argv.includes('--resume');
const limit = Number(process.argv[process.argv.indexOf('--case-limit') + 1] || 2); assert.ok(limit > 0 && limit <= 6);
assert.equal(fs.existsSync(output), resume);
const runtime = JSON.parse(fs.readFileSync('/tmp/tributary-rust-guardian/runtime.json')), manifest = JSON.parse(fs.readFileSync('/tmp/tributary-rust-guardian/artifacts/manifest.json'));
const digest = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const sourceFiles = [];
for (const dir of ['core', 'desktop', 'ui/src', 'ui/dist']) {
  for (const relative of fs.readdirSync(path.join(repo, dir), { recursive: true })) {
    const file = path.join(repo, dir, relative); if (fs.statSync(file).isFile()) sourceFiles.push(file);
  }
}
sourceFiles.push(...['package.json', 'package-lock.json', 'ui/package.json', 'ui/package-lock.json', 'native/tributary-engine/target/release/tributary-engine', 'scripts/performance/app-memory.cjs', 'scripts/performance/native-local-engine-desktop.cjs'].map(name => path.join(repo, name)));
sourceFiles.push(...['native-desktop.cjs', 'compare-desktop.cjs', 'baseline/core/local-engine-process.js', 'baseline/core/local-engine-worker.cjs'].map(name => path.join(root, name)));
sourceFiles.push(runtime.binary, '/tmp/tributary-rust-guardian/runtime.json');
sourceFiles.push(...['native/tributary-engine/Cargo.toml','native/tributary-engine/Cargo.lock','native/tributary-engine/src/main.rs','native/tributary-engine/src/runtime.rs'].map(name => path.join(repo,name)));
const hashes = () => Object.fromEntries(sourceFiles.sort().map(file => [file, digest(file)]));
const artifacts = manifest.files.map(row => ({ ...row, stat: (({ dev, ino, size, mtimeMs, ctimeMs }) => ({ dev, ino, size, mtimeMs, ctimeMs }))(fs.statSync(row.path)) }));
const report = resume ? JSON.parse(fs.readFileSync(output)) : { complete: false, sourceHashes: hashes(), artifacts, runtime, runs: [], scope: 'Final integrated native-engine guardian versus frozen legacy Electron Node-mode guardian. Actual source desktop, bridge/Hub, real pinned llama.cpp/Qwen CPU model and actual composer/model-picker actions. Three alternating fresh pairs; same two-second idle/context/batch/CPU settings, two real capped generations, six boundaries and five complete process-tree PSS samples each. No forced GC, profiler, heap snapshot, debugger or concurrent local tests/builds/performance cohorts. Installed-agent discovery and automatic update polling disabled equally only in the fixture. Candidate uses the unmodified clean publication path, including capability negotiation; only the legacy control overrides the launcher. No held refresh code or local README/docs/reports. Settled PSS is not continuous peak or whole-machine RAM; no cross-platform, installed release, coding-quality, throughput or cross-editor speed claim.' };
assert.equal(report.complete, false); assert.deepEqual(report.runtime, runtime); assert.deepEqual(report.artifacts, artifacts);
const save = () => fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
const verify = () => { assert.deepEqual(hashes(), report.sourceHashes); for (const row of artifacts) { const stat = fs.statSync(row.path); for (const [key, value] of Object.entries(row.stat)) assert.equal(stat[key], value, row.path + ':' + key); } };
if (!resume) for (const row of artifacts) { assert.equal(fs.statSync(row.path).size, row.bytes); assert.equal(digest(row.path), row.sha256); }
if (resume) for (const row of report.runs.filter(row => !row.passed && !row.excluded)) {
  try { process.kill(row.pid, 0); throw Error('Earlier child remains live: ' + row.pid); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  row.excluded = 'Terminal failed/interrupted attempt retained, not admitted.';
}
async function run(mode, repeat) {
  verify(); const attempt = report.runs.filter(row => row.mode === mode && row.repeat === repeat).length;
  const name = `desktop-${mode}-${repeat}${attempt ? '-attempt-' + attempt : ''}`, file = path.join(root, name + '.json'), log = path.join(root, name + '.log');
  assert.ok(!fs.existsSync(file)); const fd = fs.openSync(log, 'wx');
  const child = spawn('xvfb-run', ['-a', path.join(repo, 'node_modules/.bin/electron'), path.join(root, 'native-desktop.cjs'), '--no-sandbox', '--ozone-platform=x11'], {
    cwd: repo, detached: true, stdio: ['ignore', fd, fd], env: { ...process.env, TRIBUTARY_GUARDIAN_MODE: mode, TRIBUTARY_ENGINE_DESKTOP_OUTPUT: file, TRIBUTARY_ENGINE_DESKTOP_IDLE: '2', TRIBUTARY_ENGINE_DESKTOP_BINARY: runtime.binary, TRIBUTARY_ENGINE_DESKTOP_MODEL: runtime.model },
  }); fs.closeSync(fd);
  const row = { mode, repeat, pid: child.pid, file, log, passed: false }; report.runs.push(row); save();
  const code = await new Promise((resolve, reject) => {
    let hard; const timer = setTimeout(() => { row.deadlineExceeded = true; save(); try { process.kill(-child.pid, 'SIGTERM'); } catch {} hard = setTimeout(() => { try { process.kill(-child.pid, 'SIGKILL'); } catch {} }, 5000); }, 240000);
    child.once('error', error => { clearTimeout(timer); row.spawnError = error.message; save(); reject(error); });
    child.once('close', code => { clearTimeout(timer); clearTimeout(hard); resolve(code); });
  }); row.exitCode = code; save(); assert.equal(code, 0, 'Incomplete child: ' + log); verify();
  const result = JSON.parse(fs.readFileSync(file)); assert.ok(result.passed && result.guardianMode === mode && result.phases.length === 6 && result.turns.length === 2);
  for (const phase of result.phases) assert.ok(phase.samples.length === 5 && phase.samples.every(sample => sample.tree.complete));
  for (const key of ['actualUiGeneration', 'automaticWake', 'nativeAndGuardianReaped', 'modelPickerAndTenCatalogReadsPreserveSleep']) assert.equal(result.checks[key], true);
  for (const pid of [result.mainPid, result.nativePid, result.guardianPid]) {
    try { process.kill(pid, 0); throw Error('Measured process still alive/reused: ' + pid); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  }
  row.result = result; row.passed = true; save(); console.log('Completed', mode, repeat);
}
(async () => {
  let count = 0; verify(); save();
  for (let repeat = 0; repeat < 3; repeat++) for (const mode of repeat % 2 ? ['integrated', 'legacy'] : ['legacy', 'integrated']) {
    if (report.runs.some(row => row.mode === mode && row.repeat === repeat && row.passed && !row.excluded)) continue;
    if (count >= limit) { console.log('Batch complete; resume remaining cases.'); return; }
    await run(mode, repeat); count++;
  }
  verify(); for (const row of artifacts) assert.equal(digest(row.path), row.sha256);
  report.complete = true; save(); console.log('All six cases complete.');
})().catch(error => { report.error = error.stack; save(); console.error(error.stack); process.exitCode = 1; });
