'use strict';
// Functional assertion only. Original isolated native UI fixture, with an
// assertion that real successful requests do not silently use JS fallback.
const fs=require('node:fs'),path=require('node:path'),{Module}=require('node:module');
const repo='/home/ayushniroula/Desktop/projects/tributary',file=path.join(repo,'test/e2e/filename-search.cjs');
let source=fs.readFileSync(file,'utf8');
const prefix=`const __bridge=require(${JSON.stringify(path.join(repo,'core/native-engine/discovery.cjs'))});const __original=__bridge.nativeScan;let __nativeResults=0;__bridge.nativeScan=async(...args)=>{const result=await __original(...args);require('node:assert/strict').ok(result,'Successful fixture request must use native results');__nativeResults++;return result;};\n`;
source=prefix+source.replaceAll('/tmp/tributary-filename-search-ui','/tmp/tributary-rust-allocation/search-ui').replace('const report = { passed: true,',"assert.ok(__nativeResults>=3,'Real native results required'); const report = { nativeResults: __nativeResults, passed: true,");
const loaded=new Module(file,module);loaded.filename=file;loaded.paths=Module._nodeModulePaths(path.dirname(file));loaded._compile(source,file);
