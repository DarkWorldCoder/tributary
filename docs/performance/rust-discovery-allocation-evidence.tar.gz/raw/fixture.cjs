'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=__dirname, paths=[];
for(let i=0;i<20000;i++)paths.push(`Src/Group${i%8}/Source-${String(i).padStart(6,'0')}.TS`);
for(let i=0;i<8;i++)paths.push(`Src/Group${i}/Target-${String(i).padStart(6,'0')}.json`);
const layouts=[];
for(const order of ['ascending','descending','shuffled']){
 const project=path.join(root,'projects',order);assert.ok(!fs.existsSync(project));fs.mkdirSync(project,{recursive:true});const creation=[...paths].sort();
 if(order==='descending')creation.reverse();
 if(order==='shuffled'){let seed=48271;for(let i=creation.length-1;i>0;i--){seed=(seed*48271)%2147483647;const j=seed%(i+1);[creation[i],creation[j]]=[creation[j],creation[i]];}}
 for(const rel of creation){const file=path.join(project,rel);fs.mkdirSync(path.dirname(file),{recursive:true});fs.closeSync(fs.openSync(file,'wx'));}
 layouts.push({order,project,creationSha256:crypto.createHash('sha256').update(JSON.stringify(creation)).digest('hex')});
}
const queries=[['source-',100],['group',100],['/group3/',100],['target-',100],['missing-needle',100],['source-',2000]];
fs.writeFileSync(path.join(root,'fixture.json'),JSON.stringify({paths,layouts,queries,visited:paths.length+9,scope:'Three 20,008-file trees with identical names and different creation order. Empty files. Actual filesystem enumeration order is filesystem-owned, not asserted equal to creation order.'},null,2)+'\n');console.log({layouts:layouts.length,files:paths.length});
