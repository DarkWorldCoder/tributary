from pathlib import Path
import shutil,json,hashlib,subprocess
root=Path('/tmp/tributary-rust-allocation');repo=Path.cwd();current=repo/'native/tributary-engine/src/main.rs';shutil.copy2(current,root/'after.rs');shutil.copy2(repo/'native/tributary-engine/target/release/tributary-engine',root/'cand-engine')
crate=root/'baseline-crate';(crate/'src').mkdir(parents=True)
for name in ['Cargo.toml','Cargo.lock']:shutil.copy2(repo/'native/tributary-engine'/name,crate/name)
shutil.copy2(root/'before.rs',crate/'src/main.rs')
counter='''
// Diagnostic only: requested System allocator bytes, not RSS or allocator metadata.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering};
static COUNT: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
struct Counting;
fn allocated(size: usize) {
    COUNT.fetch_add(1, Ordering::Relaxed);
    REQUESTED.fetch_add(size, Ordering::Relaxed);
    let now = LIVE.fetch_add(size, Ordering::Relaxed) + size;
    PEAK.fetch_max(now, Ordering::Relaxed);
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let result = System.alloc(layout);
        if !result.is_null() { allocated(layout.size()); }
        result
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let result = System.alloc_zeroed(layout);
        if !result.is_null() { allocated(layout.size()); }
        result
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
        System.dealloc(ptr, layout);
    }
    unsafe fn realloc(&self, ptr: *mut u8, old: Layout, size: usize) -> *mut u8 {
        let result = System.realloc(ptr, old, size);
        if !result.is_null() { LIVE.fetch_sub(old.size(), Ordering::Relaxed); allocated(size); }
        result
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;
fn main() {
    scan_main();
    let (count, requested, live, peak) = (COUNT.load(Ordering::Relaxed), REQUESTED.load(Ordering::Relaxed), LIVE.load(Ordering::Relaxed), PEAK.load(Ordering::Relaxed));
    eprintln!("TRIBUTARY_ALLOCATION {} {} {} {}", count, requested, live, peak);
}
'''
for mode,name in [('base','before.rs'),('cand','after.rs')]:
 source=(root/name).read_text();assert source.count('fn main() {')==1;source=source.replace('fn main() {','fn scan_main() {',1);(root/(mode+'-diagnostic.rs')).write_text(source+counter)
print('Prepared isolated baseline crate and allocator-only diagnostics; production has no allocator instrumentation.')
