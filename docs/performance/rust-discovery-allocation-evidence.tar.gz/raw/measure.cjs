'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');const root=__dirname,phase=process.argv[2];assert.ok(['allocation','ordinary'].includes(phase));
const fixture=JSON.parse(fs.readFileSync(path.join(root,'fixture.json'))),output=path.join(root,phase+'.json');assert.ok(!fs.existsSync(output));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const bins=Object.fromEntries(['base','cand'].map(mode=>[mode,path.join(root,mode+(phase==='allocation'?'-diagnostic':'-engine'))]));
const binaries=Object.fromEntries(Object.entries(bins).map(([mode,p])=>[mode,{path:p,sha256:hash(p)}]));
const report={complete:false,phase,createdAt:new Date().toISOString(),binaries,fixtureSha256:hash(path.join(root,'fixture.json')),rows:[],scope:phase==='allocation'?'Diagnostic-only System GlobalAlloc request counts/cumulative requested bytes/peak live requested bytes, including std allocations. Excludes libc allocations outside Rust GlobalAlloc and allocator overhead; not RSS or speed.':'Five alternating uninstrumented native CLI pairs per case. Parent elapsed includes GNU time/helper startup, output transport and child exit, excludes parent JSON parsing. Kernel child-process maximum RSS via GNU time. Warm filesystem, identical fixtures and compiler profile; no tests/builds/other performance overlap. Not the full app, GUI Quick Open, model memory or VS Code.'};
const save=()=>fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');save();
for(const layout of fixture.layouts)for(const [query,limit] of fixture.queries){
 const matched=fixture.paths.filter(p=>p.toLowerCase().includes(query)).sort();const expected=matched.slice(0,limit);
 for(let repeat=0;repeat<(phase==='allocation'?1:5);repeat++)for(const mode of repeat%2?['cand','base']:['base','cand']){
  assert.equal(hash(bins[mode]),binaries[mode].sha256);
  const args=['scan-files',layout.project,query,String(limit),'true'];const start=performance.now();
  const result=phase==='allocation'?spawnSync(bins[mode],args,{encoding:'utf8',maxBuffer:4*1024**2,timeout:30000}):spawnSync('/usr/bin/time',['-f','TRIBUTARY_RSS %M',bins[mode],...args],{encoding:'utf8',maxBuffer:4*1024**2,timeout:30000});
  const elapsedMs=performance.now()-start;assert.ifError(result.error);assert.equal(result.status,0,result.stderr);assert.equal(result.signal,null);
  const values=result.stdout.trimEnd().split('\n').map(row=>JSON.parse(row));assert.deepEqual(values.shift(),{protocol:1});
  assert.deepEqual(values.pop(),{complete:true,total:matched.length,visited:fixture.visited,unreadable:0,limited:matched.length>limit});assert.deepEqual(values.map(row=>row.file),expected);
  const row={order:layout.order,query,limit,repeat,mode,wireSha256:crypto.createHash('sha256').update(result.stdout).digest('hex'),files:expected.length,total:matched.length};
  if(phase==='allocation'){
   const m=result.stderr.match(/^TRIBUTARY_ALLOCATION (\d+) (\d+) (\d+) (\d+)$/m);assert.ok(m,result.stderr);[row.allocations,row.cumulativeRequestedBytes,row.finalLiveRequestedBytes,row.peakLiveRequestedBytes]=m.slice(1).map(Number);
  }else {const m=result.stderr.match(/^TRIBUTARY_RSS (\d+)$/m);assert.ok(m,result.stderr);row.elapsedMs=elapsedMs;row.kernelMaxRssKiB=Number(m[1]);}
  report.rows.push(row);save();
 }
 console.log('Completed',phase,layout.order,query,limit);
}
for(const [mode,b] of Object.entries(binaries))assert.equal(hash(b.path),b.sha256);
report.complete=true;report.finishedAt=new Date().toISOString();save();console.log('Complete',report.rows.length);
