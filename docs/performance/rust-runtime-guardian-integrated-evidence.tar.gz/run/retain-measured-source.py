import hashlib, json, pathlib, tarfile
state = pathlib.Path('/tmp/tributary-rust-guardian-integration')
report = json.loads((state / 'performance/desktop-comparison.json').read_text())
assert report['complete']
archive = pathlib.Path('/home/ayushniroula/Desktop/projects/tributary/docs/performance/rust-runtime-guardian-integrated-measured-source.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name, expected in report['sourceHashes'].items():
        p = pathlib.Path(name); assert hashlib.sha256(p.read_bytes()).hexdigest() == expected
        tar.add(p, arcname=str(p.relative_to('/tmp')), recursive=False)
with tarfile.open(archive) as tar:
    for name, expected in report['sourceHashes'].items():
        assert hashlib.sha256(tar.extractfile(str(pathlib.Path(name).relative_to('/tmp'))).read()).hexdigest() == expected
(state / 'measured-source-archive.json').write_text(json.dumps({'path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}, indent=2) + '\n')
print(str(archive))
