import json, pathlib, subprocess

state = pathlib.Path('/tmp/tributary-rust-guardian-integration')
repo = pathlib.Path('/home/ayushniroula/Desktop/projects/tributary')
pub = pathlib.Path(json.loads((state / 'publication.json').read_text())['root'])
root = state / 'performance'
root.mkdir()
for name in ['core/local-engine-process.js', 'core/local-engine-worker.cjs']:
    target = root / 'baseline' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=repo))

source = pathlib.Path('/tmp/tributary-rust-guardian/native-desktop.cjs').read_text()
source = source.replace(str(repo), str(pub))
source = source.replace("['legacy','rust']", "['legacy','integrated']")
source = source.replace("if (guardianMode === 'rust') ownerModule.spawnOwnedRuntime = require('/tmp/tributary-rust-guardian/prototype-owner.cjs').spawnOwnedRuntime;", "if (guardianMode === 'legacy') ownerModule.spawnOwnedRuntime = require('/tmp/tributary-rust-guardian-integration/performance/baseline/core/local-engine-process.js').spawnOwnedRuntime;")
needle = 'nativePid = hub.localEngine.child.runtimePid; guardianPid = hub.localEngine.child.pid; assert.ok(Number.isSafeInteger(nativePid));'
assert source.count(needle) == 1
source = source.replace(needle, needle + "\n    if (guardianMode === 'integrated') assert.equal(hub.localEngine.child.backend, 'native', 'Reject silent compatibility fallback in measured candidate');")
source = source.replace('legacy Electron Node-mode or isolated prototype Rust guardian', 'frozen legacy Electron Node-mode or final integrated native-engine guardian')
source = source.replace('Prototype-only ownership override; production source unchanged.', 'Only the legacy control overrides launch; candidate uses the clean final native path with capability validation and fallback.')
(root / 'native-desktop.cjs').write_text(source)

controller = pathlib.Path('/tmp/tributary-rust-guardian/compare-desktop.cjs').read_text()
controller = controller.replace("const repo = '/home/ayushniroula/Desktop/projects/tributary', root = '/tmp/tributary-rust-guardian';", "const repo = " + json.dumps(str(pub)) + ", root = '/tmp/tributary-rust-guardian-integration/performance';")
controller = controller.replace("path.join(root, 'runtime.json')", "'/tmp/tributary-rust-guardian/runtime.json'")
controller = controller.replace("path.join(root, 'artifacts/manifest.json')", "'/tmp/tributary-rust-guardian/artifacts/manifest.json'")
controller = controller.replace("['native-desktop.cjs', 'compare-desktop.cjs', 'prototype-owner.cjs', 'prototype/Cargo.toml', 'prototype/Cargo.lock', 'prototype/src/main.rs', 'prototype/target/release/tributary-guardian-prototype']", "['native-desktop.cjs', 'compare-desktop.cjs', 'baseline/core/local-engine-process.js', 'baseline/core/local-engine-worker.cjs']")
controller = controller.replace("path.join(root, 'runtime.json')", "'/tmp/tributary-rust-guardian/runtime.json'")
controller = controller.replace("['rust', 'legacy'] : ['legacy', 'rust']", "['integrated', 'legacy'] : ['legacy', 'integrated']")
controller = controller.replace('Isolated Rust guardian prototype versus current Electron Node-mode guardian.', 'Final integrated native-engine guardian versus frozen legacy Electron Node-mode guardian.')
controller = controller.replace('Prototype override stays outside production source.', 'Candidate uses the unmodified clean publication path, including capability negotiation; only the legacy control overrides the launcher. No held refresh code or local README/docs/reports.')
(root / 'compare-desktop.cjs').write_text(controller)
print(str(root))
