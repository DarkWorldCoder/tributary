import json, pathlib, statistics, time, os

root = pathlib.Path('/tmp/tributary-rust-guardian-integration/performance')
report = json.loads((root / 'desktop-comparison.json').read_text())
assert report['complete'] and len(report['runs']) == 6
rows = []
for row in report['runs']:
    assert row['passed'] and not row.get('excluded')
    result = row['result']; phases = {}
    for phase in result['phases']:
        samples = phase['samples']
        assert len(samples) == 5 and all(sample['tree']['complete'] for sample in samples)
        values = {
            'treePssKiB': statistics.median(sample['tree']['totals']['pssKiB'] for sample in samples),
            'treePrivateKiB': statistics.median(sample['tree']['totals']['privateKiB'] for sample in samples),
            'guardianPssKiB': statistics.median(next((p['pssKiB'] for p in sample['tree']['processes'] if p['pid'] == result['guardianPid']), 0) for sample in samples),
            'nativePssKiB': statistics.median(next((p['pssKiB'] for p in sample['tree']['processes'] if p['pid'] == result['nativePid']), 0) for sample in samples),
            'nativeAnonPssKiB': statistics.median(sample['nativeMemory']['Pss_Anon'] for sample in samples),
            'nativeFilePssKiB': statistics.median(sample['nativeMemory']['Pss_File'] for sample in samples),
            'engineStatus': phase['engineState']['status'],
        }
        if phase['label'] not in ['desktop-baseline', 'after-stop']:
            role = 'child:electron' if row['mode'] == 'legacy' else 'child:tributary-engine'
            for sample in samples:
                assert next(p for p in sample['tree']['processes'] if p['pid'] == result['guardianPid'])['role'] == role
                assert next(p for p in sample['tree']['processes'] if p['pid'] == result['nativePid'])['role'] == 'child:llama-server'
        phases[phase['label']] = values
    assert [phase['engineStatus'] for phase in phases.values()] == ['stopped', 'ready', 'sleeping', 'sleeping', 'ready', 'stopped']
    rows.append({'mode': row['mode'], 'repeat': row['repeat'], 'phases': phases, 'rejectedSamples': len(result['rejectedSamples'])})
labels = list(rows[0]['phases'])
keys = ['treePssKiB', 'treePrivateKiB', 'guardianPssKiB', 'nativePssKiB', 'nativeAnonPssKiB', 'nativeFilePssKiB']
summary = {mode: {label: {key: statistics.median(row['phases'][label][key] for row in rows if row['mode'] == mode) for key in keys} for label in labels} for mode in ['legacy', 'integrated']}
pairs = []
for repeat in range(3):
    a = next(row for row in rows if row['repeat'] == repeat and row['mode'] == 'legacy')
    b = next(row for row in rows if row['repeat'] == repeat and row['mode'] == 'integrated')
    pairs.append({'repeat': repeat, 'treePssDeltaKiB': {label: b['phases'][label]['treePssKiB'] - a['phases'][label]['treePssKiB'] for label in labels}})
output = {'complete': True, 'apps': 6, 'completeSamples': 180, 'rows': rows, 'summary': summary, 'pairs': pairs, 'scope': report['scope']}
(root / 'summary.json').write_text(json.dumps(output, indent=2) + '\n')
(root / 'host-end.json').write_text(json.dumps({'at': time.time(), 'cpus': os.cpu_count(), 'affinity': sorted(os.sched_getaffinity(0)), 'pressure': {name: pathlib.Path('/proc/pressure/' + name).read_text() for name in ['cpu', 'memory', 'io']}}, indent=2) + '\n')
print(json.dumps({'summaryMiB': {mode: {label: {key: round(values[key] / 1024, 3) for key in ['treePssKiB', 'guardianPssKiB', 'nativePssKiB']} for label, values in phases.items()} for mode, phases in summary.items()}, 'pairs': pairs, 'rejectedSamples': sum(row['rejectedSamples'] for row in rows)}, indent=2))
