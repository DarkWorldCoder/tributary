import hashlib,json,pathlib,tarfile,time,shutil
root=pathlib.Path('/home/ayushniroula/Desktop/projects/tributary'); run=pathlib.Path('/tmp/tributary-rust-guardian-integration'); out=root/'docs/performance'; prefix='rust-runtime-guardian-integrated'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
 p=out/(prefix+'-'+name+'.json'); p.write_text(json.dumps(v,indent=2)+'\n'); return p
summary=json.loads((run/'performance/summary.json').read_text()); publication=json.loads((run/'publication.json').read_text()); receipt=json.loads((run/'publication-commit.json').read_text())
save('summary',summary); save('publication',{'source':publication,'commit':receipt,'workflowRuns':json.loads((run/'release-runs.json').read_text()),'docsAndReportsPublished':False,'recordedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
reading=out/'rust-runtime-guardian-reading.json'
if reading.exists(): shutil.copyfile(reading,out/(prefix+'-reading.json'))
items=[p for p in run.iterdir() if p.is_file() and p.suffix in ('.log','.json','.py','.patch','.png')]
items += [p for p in (run/'performance').rglob('*') if p.is_file() and p.suffix in ('.json','.log','.cjs','.js','.png')]
# Preserve final formatted publication sources independently of the exact pre-format measured archive.
source_root=pathlib.Path(publication['root']); sources=[]
for rel,expected in publication['ownedSourceHashes'].items():
 p=source_root/rel; assert sha(p)==expected,rel; sources.append((p,'publication-source/'+rel))
binary=root/'native/tributary-engine/target/release/tributary-engine'
assert sha(binary)==publication['nativeBinarySha256']
entries=[(p,'run/'+str(p.relative_to(run))) for p in items]+sources+[(binary,'publication-source/native/tributary-engine/target/release/tributary-engine')]
archive=out/(prefix+'-evidence.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p,name in sorted(entries,key=lambda e:e[1]): t.add(p,arcname=name,recursive=False)
index={'scope':'Local evidence only. No credentials, model weights, runtime download archives, node_modules, app profiles or full Electron distribution copied. Earlier measured source archive remains separately bound.','evidenceArchive':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size},'measuredSourceArchive':json.loads((run/'measured-source-archive.json').read_text()),'files':[{'path':n,'sha256':sha(p),'bytes':p.stat().st_size} for p,n in sorted(entries,key=lambda e:e[1])],'formatting':publication['postMeasurementFormatting'],'formatOnlyRebuildIdenticalBinary':publication['formatOnlyRebuildIdenticalBinary']}
save('evidence-index',index)
with tarfile.open(archive) as t:
 members=t.getmembers(); assert len(members)==len(entries)
 for e in index['files']:
  f=t.extractfile(e['path']); assert f and hashlib.sha256(f.read()).hexdigest()==e['sha256'],e['path']
protected=json.loads((out/'focus-selectors-restoration.json').read_text())['protectedHashes']; skip={'package.json','docs/MEMORY_OPTIMIZATION_RESEARCH.md','native/tributary-engine/src/main.rs','native/tributary-engine/target/release/tributary-engine'}
checks={n:sha(root/n)==v for n,v in protected.items() if n not in skip}; assert all(checks.values()),checks
save('preservation',{'checks':checks,'scope':'Historical protected files excluding intentionally changed package/native source/binary and cumulative local research notes.','allPreserved':True})
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'verifiedFiles':len(entries),'protectedFiles':len(checks)}))
