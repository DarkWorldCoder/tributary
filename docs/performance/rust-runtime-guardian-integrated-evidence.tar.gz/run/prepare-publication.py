import hashlib, json, pathlib, shutil, subprocess, tarfile, tempfile

repo = pathlib.Path('/home/ayushniroula/Desktop/projects/tributary')
state = pathlib.Path('/tmp/tributary-rust-guardian-integration')
dest = pathlib.Path(tempfile.mkdtemp(prefix='tributary-runtime-publication-'))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
process = subprocess.Popen(['git', 'archive', '--format=tar', head], cwd=repo, stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout, mode='r|') as tar: tar.extractall(dest, filter='data')
assert process.wait() == 0
owned = ['.github/workflows/distribution.yml', 'core/local-engine.js', 'core/local-engine-process.js', 'core/local-engine-worker.cjs', 'core/native-engine/runtime.cjs',
         'native/tributary-engine/Cargo.toml', 'native/tributary-engine/Cargo.lock', 'native/tributary-engine/src/main.rs', 'native/tributary-engine/src/runtime.rs',
         'scripts/build-native.cjs', 'scripts/native-licenses.cjs', 'scripts/verify-distribution.cjs', 'test/runtime-owner.test.cjs', 'test/runtime-owner-parent.cjs', 'test/fake-runtime-helper.cjs',
         'test/e2e/local-engine-asar.cjs', 'test/e2e/local-engine-ui.cjs']
owned += [str(p.relative_to(repo)) for p in (repo / 'native/tributary-engine/licenses').rglob('*') if p.is_file()]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
hashes = {}
for name in owned:
    source, target = repo / name, dest / name
    target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, target); hashes[name] = sha(source)

# Publish only this task's package changes. Keep the held refresh-test addition
# and every README/documentation/report change out of this candidate.
pkg = json.loads((dest / 'package.json').read_text())
assert 'test/runtime-owner.test.cjs' not in pkg['scripts']['test']
pkg['scripts']['test'] += ' test/runtime-owner.test.cjs'
assert 'licenses/**' not in pkg['build']['extraResources'][0]['filter']
pkg['build']['extraResources'][0]['filter'].append('licenses/**')
(dest / 'package.json').write_text(json.dumps(pkg, indent=2) + '\n')
assert 'test/file-refresh.test.mjs' not in pkg['scripts']['test']
hashes['package.json'] = sha(dest / 'package.json')
for folder in ['node_modules', 'ui/node_modules']:
    target = dest / folder
    assert not target.exists(); target.symlink_to(repo / folder, target_is_directory=True)
target = dest / 'native/tributary-engine/target/release'
target.mkdir(parents=True)
shutil.copy2(repo / 'native/tributary-engine/target/release/tributary-engine', target / 'tributary-engine')
shutil.copytree(repo / 'native/tributary-engine/target/release/licenses', target / 'licenses')
report = {'root': str(dest), 'baselineCommit': head, 'ownedSourceHashes': hashes,
          'nativeBinarySha256': sha(target / 'tributary-engine'),
          'rootPackageSha256WithHeldWork': sha(repo / 'package.json'),
          'scope': 'Clean main export plus only integrated native ownership/packaging/tests/licenses. No README, docs, benchmark reports or held refresh implementation/tests. Existing dependencies symlinked; exact current native executable/notices copied, not rebuilt.'}
(state / 'publication.json').write_text(json.dumps(report, indent=2) + '\n')
print(str(dest))
