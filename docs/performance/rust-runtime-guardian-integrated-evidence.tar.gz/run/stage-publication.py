import hashlib, json, pathlib, subprocess

repo = pathlib.Path('/home/ayushniroula/Desktop/projects/tributary')
state = pathlib.Path('/tmp/tributary-rust-guardian-integration')
report = json.loads((state / 'publication.json').read_text())
pub = pathlib.Path(report['root'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
assert git('branch', '--show-current').strip() == b'main'
assert git('rev-parse', 'HEAD').decode().strip() == report['baselineCommit']
assert git('rev-parse', 'origin/main').decode().strip() == report['baselineCommit']
files = list(report['ownedSourceHashes'])
assert len(files) == 32
cached = git('diff', '--name-only', '--cached', '-z').decode().split('\0')[:-1]
assert not cached or sorted(cached) == sorted(files)
if cached:
    previous = {row['path']: row['beforeSha256'] for row in report.get('postMeasurementFormatting', [])}
    for name, expected in report['ownedSourceHashes'].items():
        assert hashlib.sha256(git('show', ':' + name)).hexdigest() in {expected, previous.get(name)}
for name, expected in report['ownedSourceHashes'].items():
    assert not name.startswith(('docs/', 'README', 'scripts/performance/')) and pathlib.Path(name).suffix.lower() != '.md'
    assert (repo / name).resolve().is_relative_to(repo)
    assert sha(pub / name) == expected
    if name != 'package.json': assert sha(repo / name) == expected
assert sha(repo / 'package.json') == report['rootPackageSha256WithHeldWork']
assert b'test/file-refresh.test.mjs' not in (pub / 'package.json').read_bytes()
subprocess.run(['git', 'add', '--', *[name for name in files if name != 'package.json']], cwd=repo, check=True)
blob = git('hash-object', '-w', str(pub / 'package.json')).decode().strip()
subprocess.run(['git', 'update-index', '--cacheinfo', '100644,' + blob + ',package.json'], cwd=repo, check=True)
staged = git('diff', '--cached', '--name-only', '-z').decode().split('\0')[:-1]
assert sorted(staged) == sorted(files)
for name, expected in report['ownedSourceHashes'].items():
    assert hashlib.sha256(git('show', ':' + name)).hexdigest() == expected
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=repo, check=True)
(state / 'publication.patch').write_bytes(git('diff', '--cached', '--binary'))
(state / 'staged-verification.json').write_text(json.dumps({'baselineCommit': report['baselineCommit'], 'files': staged, 'sourceHashes': report['ownedSourceHashes'], 'packageGitBlob': blob, 'noReadmeDocsBenchmarksOrHeldRefresh': True}, indent=2) + '\n')
print(json.dumps({'stagedFiles': len(staged), 'docsExcluded': True, 'heldRefreshExcluded': True}, indent=2))
